﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LexiconExcercise3
{
    class PersonHandler
    {

        //private Person person;

        public void SetAge(Person person,int age)
        {
            person.Age = age;
        }

        public void SetWeight(Person person, double weight)
        {
            person.Weight = weight;
        }
        public void SetHeight(Person person, double height)
        {
            person.Height = height;
        }
        public void SetLastName(Person person, string lastName)
        {
            person.LastName = lastName;
        }
        public void SetFirstName(Person person, string firstName)
        {
            person.FirstName = firstName;
        }

        public int GetAge(Person person)
        {
            return person.Age;

        }

        public double GetWeight(Person person)
        {
            return person.Weight;

        }




        public double GetHeight(Person person)
        {
            return person.Height;

        }

        public string GetFirstName(Person person)
        {
            return person.FirstName;

        }

        public string GetLastName(Person person)
        {
            return person.LastName;

        }




        public Person CreatePerson(int age,string firstName, string lastName, double height, double weight)
        {
            Person person = new Person();
            SetAge(person,age);
            SetFirstName(person,firstName);
            SetLastName(person,lastName);
            SetHeight(person,height);
            SetWeight(person,weight);
            return person;
        }


        
        
    }
}
