﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LexiconExcercise3
{
    class Program
    {
        static void Main(string[] args)
        {
            
            List<Person> personList = new List<Person>();
            
            PersonHandler person = new PersonHandler();
            bool quit = false;
            do
            {
                Console.Clear();
                string choice;
                choice = MainMenu();

                switch (choice)
                {
                    case "A":
                        {
                            //Console.Clear();
                            AddPerson(personList, person);
                        }
                        break;

                    case "V":
                        {
                            //Console.Clear();
                            ViewRecords(personList,person);
                        }
                        break;
                    case "F":
                        {
                            FindRecord(personList,person);
                            Console.ReadKey();
                        }
                        break;
                    case "U":

                        UpdateRecord(personList,person);
                        break;

                    case "D":
                        DeleteRecord(personList);
                        Console.ReadKey();
                        break;
                    case "Q":
                        quit = true;
                        break;
                        
                    default:
                        quit = false;
                        break;
                }




            }
            while (!quit);


            Console.ReadKey();

        }

        private static void AddPerson(List<Person> personList, PersonHandler person)
        {
            int age;
            string firstName, lastName;
            double height, weight;
            firstName = AskforString("Enter First Name").ToUpper();
            lastName = AskforString("Enter Last Name").ToUpper();
            age = AskForInt("Enter Age of Person");
            height = AskForInt("Enter Height of Person");
            weight = AskForInt("Enter Weight of Person");
          
            personList.Add(person.CreatePerson(age, firstName, lastName, height, weight));

        }

        private static void FindRecord(List<Person> personList,PersonHandler person)
        {
            string value = AskforString("Enter Name of Person to find").ToUpper();
            bool checkResult = false;

            foreach (var list in personList)
            {

                if (list.FirstName == value)
                {
                    Console.WriteLine(" First Name:   " + person.GetFirstName(list));
                    Console.WriteLine(" Last Name: " + person.GetFirstName(list));
                    Console.WriteLine(" Age of Person: " + person.GetAge(list));
                    Console.WriteLine(" Height of Person: " + person.GetHeight(list));
                    Console.WriteLine(" Weitht of Person: " + person.GetWeight(list));
                    Console.WriteLine("----------------------------------");
                    checkResult = true;
                    
                }

            }

            if (!checkResult)
            {
                Console.WriteLine("Record Not Existed");
            }
        }

        private static void DeleteRecord(List<Person> personList)
        {
            string value = AskforString("Enter Name of Person to Delete").ToUpper();
            int position=0;
            foreach (var list in personList)
            {
              
                if (list.FirstName == value)
                {
                    Console.WriteLine(" First Name: " + list.FirstName);
                    Console.WriteLine(" Last Name: " + list.LastName);
                    Console.WriteLine(" Age of Person: " + list.Age);
                    Console.WriteLine(" Height of Person: " + list.Height);
                    Console.WriteLine(" Weitht of Person: " + list.Weight);
                    Console.WriteLine("----------------------------------");
                    string result= AskforString("Do You want to remove it Y/N").ToUpper();
                    if (result == "Y")
                    {
                        personList.RemoveAt(position);
                        Console.Clear();
                        Console.WriteLine("Record is Deleted");
                        Console.ReadKey();
                        break;
                    }

                    break;
                }
                position += 1;
            }

            
        }

        private static void UpdateRecord(List<Person> personList, PersonHandler person)
        {

            string value = AskforString("Enter Name of Person to update").ToUpper();
            int position = 0;
            foreach (var list in personList)
            {

                if (list.FirstName == value)
                {
                    Console.WriteLine(" First Name:   " + person.GetFirstName(list));
                    Console.WriteLine(" Last Name: " + person.GetLastName(list));
                    Console.WriteLine(" Age of Person: " + person.GetAge(list));
                    Console.WriteLine(" Height of Person: " + person.GetHeight(list));
                    Console.WriteLine(" Weitht of Person: " + person.GetWeight(list));
                    Console.WriteLine("----------------------------------");
                    string result = AskforString("Do You want to Update it Y/N").ToUpper();
                    if (result == "Y")
                    {

                        person.SetFirstName(list, AskforString("Enter First Name").ToUpper());
                        person.SetLastName(list, AskforString("Enter Last Name").ToUpper());
                        person.SetAge(list, AskForInt("Enter Age of Person"));
                        person.SetHeight(list, AskForInt("Enter Height of Person"));
                        person.SetWeight(list, AskForInt("Enter Weight of Person"));
                                                                    
                        
                        Console.Clear();
                        Console.WriteLine("Record is updated");
                        Console.ReadKey();
                        break;
                    }

                    break;
                }
                position += 1;
            }


        }

        private static void ViewRecords(List<Person> personList,PersonHandler person)
        {
            foreach (var list in personList)
            {
                Console.WriteLine(" First Name:   " + person.GetFirstName(list));
                Console.WriteLine(" Last Name: " + person.GetLastName(list));
                Console.WriteLine(" Age of Person: " + person.GetAge(list));
                Console.WriteLine(" Height of Person: " + person.GetHeight(list));
                Console.WriteLine(" Weitht of Person: " + person.GetWeight(list));
                Console.WriteLine("----------------------------------");
                
            }

            Console.ReadKey();
        }

        private static string MainMenu()
        {
            string choice;
            Console.WriteLine("------------------------");
            Console.WriteLine(" Person Handling DataBase");
            Console.WriteLine(" A: Enter record of person");
            Console.WriteLine("V: View Records of all persons");
            Console.WriteLine("F: Find Record of any person");
            Console.WriteLine("U: Update Record of any person");
            Console.WriteLine("D: Delete Record of any person");
            Console.WriteLine("Q: Quit the program");
            choice = AskforString("Enter Choice >>>").ToUpper();
            return choice;
        }

        private static string AskforString(string question)
        {
            Console.WriteLine(question);
            return Console.ReadLine();
        }

        private static int AskForInt(string question)
        {
            string parse;
            int input;
            bool result = false;
            string error = "";
            do
            {

                parse = AskforString(error + question);
                result = int.TryParse(parse, out input);
                error = "Kindly enter correct Numbers ";

            }
            while (!result);
            return input;
        }
    }
}
